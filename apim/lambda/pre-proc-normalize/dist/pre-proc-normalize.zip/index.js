// Minimal pre-processing Lambda that forwards to an internal NLB HTTP endpoint.
import https from "https";
import http from "http";

// Expect process.env.NLB_URL like "internal-eks-xxxx.elb.amazonaws.com"
const NLB_URL = process.env.NLB_URL;
const NLB_PORT = process.env.NLB_PORT ? Number(process.env.NLB_PORT) : 80;

export const handler = async (event) => {
  // API GW HTTP API (payload v2.0)
  const path = event.rawPath || "/";
  const qs   = event.rawQueryString ? `?${event.rawQueryString}` : "";
  const method = event.requestContext?.http?.method || "GET";
  const headers = event.headers || {};
  const body = event.body && event.isBase64Encoded ? Buffer.from(event.body, "base64") : event.body;

  const options = {
    hostname: NLB_URL,
    port: NLB_PORT,
    path: `${path}${qs}`,
    method,
    headers: {
      ...headers,
      "x-pre-processed": "true"
    }
  };

  const client = NLB_PORT === 443 ? https : http;

  const response = await new Promise((resolve, reject) => {
    const req = client.request(options, (res) => {
      let chunks = [];
      res.on("data", (d) => chunks.push(d));
      res.on("end", () => {
        const payload = Buffer.concat(chunks);
        const isBinary = false; // ajusta si esperas binarios
        resolve({
          statusCode: res.statusCode || 502,
          headers: Object.fromEntries(Object.entries(res.headers).map(([k,v]) => [k, Array.isArray(v)? v.join(","): v])),
          isBase64Encoded: isBinary,
          body: isBinary ? payload.toString("base64") : payload.toString()
        });
      });
    });
    req.on("error", reject);
    if (body) req.write(typeof body === "string" ? body : JSON.stringify(body));
    req.end();
  });

  return response;
};
